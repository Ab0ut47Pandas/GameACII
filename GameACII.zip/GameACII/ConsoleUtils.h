#ifndef CONSOLEUTILS_H
#define CONSOLEUTILS_H

void getConsoleSize(int& width, int& height);
void setCursorPosition(int x, int y);

#endif // CONSOLEUTILS_H