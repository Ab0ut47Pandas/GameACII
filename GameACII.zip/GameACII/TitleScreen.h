#pragma once
#ifndef TITLESCREEN_H
#define TITLESCREEN_H

class TitleScreen {
public:
    TitleScreen();
    void display() const;
    int menu() const;
};

#endif // TITLESCREEN_H